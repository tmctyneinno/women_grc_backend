
<nav id="sidebar" aria-label="Main Navigation">
<!-- Side Header -->
<div class="content-header">
    <!-- Logo -->
    <a class="fw-semibold text-dual" href="index.html">
    <span class="smini-visible">
        <i class="fa fa-circle-notch text-primary"></i>
    </span>
    <span class="smini-hide fs-5 tracking-wider">WGRCFP</span>
    </a>
    <!-- END Logo -->

    <!-- Extra -->
    <div class="d-flex align-items-center gap-1">
    <!-- Dark Mode -->
    <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
    <div class="dropdown">
        <button type="button" class="btn btn-sm btn-alt-secondary" id="sidebar-dark-mode-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="far fa-fw fa-moon" data-dark-mode-icon></i>
        </button>
        <div class="dropdown-menu dropdown-menu-end smini-hide border-0" aria-labelledby="sidebar-dark-mode-dropdown">
        <button type="button" class="dropdown-item d-flex align-items-center gap-2" data-toggle="layout" data-action="dark_mode_off" data-dark-mode="off">
            <i class="far fa-sun fa-fw opacity-50"></i>
            <span class="fs-sm fw-medium">Light</span>
        </button>
        <button type="button" class="dropdown-item d-flex align-items-center gap-2" data-toggle="layout" data-action="dark_mode_on" data-dark-mode="on">
            <i class="far fa-moon fa-fw opacity-50"></i>
            <span class="fs-sm fw-medium">Dark</span>
        </button>
        <button type="button" class="dropdown-item d-flex align-items-center gap-2" data-toggle="layout" data-action="dark_mode_system" data-dark-mode="system">
            <i class="fa fa-desktop fa-fw opacity-50"></i>
            <span class="fs-sm fw-medium">System</span>
        </button>
        </div>
    </div>
    <!-- END Dark Mode -->

    <!-- Options -->
    <div class="dropdown">
        <button type="button" class="btn btn-sm btn-alt-secondary" id="sidebar-themes-dropdown" data-bs-auto-close="outside" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-fw fa-brush"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-end fs-sm smini-hide border-0" aria-labelledby="sidebar-themes-dropdown">
        <!-- Color Themes -->
        <!-- Layout API, functionality initialized in Template._uiHandleTheme() -->
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="default">
            <span>Default</span>
            <i class="fa fa-circle text-default"></i>
        </button>
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="assets/css/themes/amethyst.min.css">
            <span>Amethyst</span>
            <i class="fa fa-circle text-amethyst"></i>
        </button>
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="assets/css/themes/city.min.css">
            <span>City</span>
            <i class="fa fa-circle text-city"></i>
        </button>
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="assets/css/themes/flat.min.css">
            <span>Flat</span>
            <i class="fa fa-circle text-flat"></i>
        </button>
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="assets/css/themes/modern.min.css">
            <span>Modern</span>
            <i class="fa fa-circle text-modern"></i>
        </button>
        <button class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="assets/css/themes/smooth.min.css">
            <span>Smooth</span>
            <i class="fa fa-circle text-smooth"></i>
        </button>
        <!-- END Color Themes -->

        <div class="dropdown-divider d-dark-none"></div>

        <!-- Sidebar Styles -->
        <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
        <a class="dropdown-item fw-medium d-dark-none" data-toggle="layout" data-action="sidebar_style_light" href="javascript:void(0)">
            <span>Sidebar Light</span>
        </a>
        <a class="dropdown-item fw-medium d-dark-none" data-toggle="layout" data-action="sidebar_style_dark" href="javascript:void(0)">
            <span>Sidebar Dark</span>
        </a>
        <!-- END Sidebar Styles -->

        <div class="dropdown-divider d-dark-none"></div>

        <!-- Header Styles -->
        <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
        <a class="dropdown-item fw-medium d-dark-none" data-toggle="layout" data-action="header_style_light" href="javascript:void(0)">
            <span>Header Light</span>
        </a>
        <a class="dropdown-item fw-medium d-dark-none" data-toggle="layout" data-action="header_style_dark" href="javascript:void(0)">
            <span>Header Dark</span>
        </a>
        <!-- END Header Styles -->
        </div>
    </div>
    <!-- END Options -->

    <!-- Close Sidebar, Visible only on mobile screens -->
    <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
    <a class="d-lg-none btn btn-sm btn-alt-secondary ms-1" data-toggle="layout" data-action="sidebar_close" href="javascript:void(0)">
        <i class="fa fa-fw fa-times"></i>
    </a>
    <!-- END Close Sidebar -->
    </div>
    <!-- END Extra -->
</div>
<!-- END Side Header -->

<!-- Sidebar Scrolling -->
<div class="js-sidebar-scroll">
    <!-- Side Navigation -->
    <div class="content-side">
    @php($admin = auth('admin')->user())
    <ul class="nav-main">
        <li class="nav-main-item">
        <a class="nav-main-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">
            <i class="nav-main-link-icon si si-speedometer"></i>
            <span class="nav-main-link-name">Dashboard</span>
        </a>
        </li>
        
        <li class="nav-main-heading">Core</li>
        @if($admin && ($admin->isSuperAdmin() || $admin->hasPermission('users.view')))
        <li class="nav-main-item">
            <a class="nav-main-link nav-main-link-submenu {{ request()->routeIs('admin.users.*') ? 'active' : '' }}" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                <i class="nav-main-link-icon si si-users"></i>
                <span class="nav-main-link-name">Users</span>
            </a>
            <ul class="nav-main-submenu">
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.users.index') ? 'active' : '' }}" href="{{ route('admin.users.index') }}">
                        <span class="nav-main-link-name">All Users</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.users.pend') ? 'active' : '' }}" href="{{ route('admin.users.pend') }}">
                        <span class="nav-main-link-name">Pending Users</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.users.blocked') ? 'active' : '' }}" href="{{ route('admin.users.blocked') }}">
                        <span class="nav-main-link-name">Blocked Users</span>
                    </a>
                </li>
            </ul>
        </li>
        @endif
        @if($admin && ($admin->isSuperAdmin() || $admin->hasPermission('mentors.view')))
        <li class="nav-main-item">
            <a class="nav-main-link nav-main-link-submenu {{ request()->routeIs('admin.mentors.*') ? 'active' : '' }}" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                <i class="nav-main-link-icon si si-user-follow"></i>
                <span class="nav-main-link-name">Mentorship</span>
            </a>
            <ul class="nav-main-submenu">
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.mentors.index') ? 'active' : '' }}" href="{{ route('admin.mentors.index') }}">
                        <span class="nav-main-link-name">Mentors</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.mentors.applications') ? 'active' : '' }}" href="{{ route('admin.mentors.applications') }}">
                        <span class="nav-main-link-name">Mentor Applications</span>
                    </a>
                </li>
                @if($admin->isSuperAdmin() || $admin->hasPermission('mentors.create'))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.mentors.create') ? 'active' : '' }}" href="{{ route('admin.mentors.create') }}">
                        <span class="nav-main-link-name">Add Mentor</span>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        @endif
        @if($admin && $admin->isSuperAdmin())
        <li class="nav-main-item">
            <a class="nav-main-link {{ request()->routeIs('admin.admins.*') ? 'active' : '' }}" href="{{ route('admin.admins.index') }}">
                <i class="nav-main-link-icon si si-user-follow"></i>
                <span class="nav-main-link-name">Admins</span>
            </a>
        </li>
        <li class="nav-main-item">
            <a class="nav-main-link {{ request()->routeIs('admin.admins.activity') ? 'active' : '' }}" href="{{ route('admin.admins.activity') }}">
                <i class="nav-main-link-icon si si-clock"></i>
                <span class="nav-main-link-name">Admin Activity</span>
            </a>
        </li>
        @endif

        <li class="nav-main-heading">Learning</li>
        @if($admin && $admin->hasPermission('courses.view'))
        <li class="nav-main-item">
            <a class="nav-main-link nav-main-link-submenu {{ request()->routeIs('admin.courses.*') || request()->routeIs('admin.modules.*') || request()->routeIs('admin.lessons.*') || request()->routeIs('admin.quizzes.*') ? 'active' : '' }}" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                <i class="nav-main-link-icon si si-graduation"></i>
                <span class="nav-main-link-name">Courses</span>
            </a>
            <ul class="nav-main-submenu">
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.courses.index') ? 'active' : '' }}" href="{{ route('admin.courses.index') }}">
                        <span class="nav-main-link-name">All Courses</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.modules.all') ? 'active' : '' }}" href="{{ route('admin.modules.all') }}">
                        <span class="nav-main-link-name">All Modules</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.lessons.all') ? 'active' : '' }}" href="{{ route('admin.lessons.all') }}">
                        <span class="nav-main-link-name">All Lessons</span>
                    </a>
                </li>
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.quizzes.all') ? 'active' : '' }}" href="{{ route('admin.quizzes.all') }}">
                        <span class="nav-main-link-name">All Quiz</span>
                    </a>
                </li>
               
            </ul>
        </li>
        @endif
        
        <li class="nav-main-heading">Engagement</li>
        @if($admin && ($admin->hasPermission('events.view') || $admin->hasPermission('articles.view') || $admin->hasPermission('podcasts.view')))
        <li class="nav-main-item">
            <a class="nav-main-link nav-main-link-submenu {{ request()->routeIs('admin.events.*') || request()->routeIs('admin.podcasts.*') ? 'active' : '' }}" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                <i class="nav-main-link-icon si si-calendar"></i>
                <span class="nav-main-link-name">Events</span>
            </a>
            <ul class="nav-main-submenu">
                @if($admin->hasPermission('events.view'))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.events.index') ? 'active' : '' }}" href="{{ route('admin.events.index') }}">
                        <span class="nav-main-link-name">All Events</span>
                    </a>
                </li>
                @if($admin->hasPermission('events.create'))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.events.create') ? 'active' : '' }}" href="{{ route('admin.events.create') }}">
                        <span class="nav-main-link-name">Create Event</span>
                    </a>
                </li>
                @endif
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.events.calendar') ? 'active' : '' }}" href="{{ route('admin.events.calendar') }}">
                        <span class="nav-main-link-name">Calendar View</span>
                    </a>
                </li>
                @endif
                @if($admin->hasPermission('podcasts.view'))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.podcasts.index') ? 'active' : '' }}" href="{{ route('admin.podcasts.index') }}">
                        <span class="nav-main-link-name">Podcasts</span>
                    </a>
                </li>
                @endif
                @if($admin && ($admin->isSuperAdmin() || $admin->hasPermission('articles.view')))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.articles.*') ? 'active' : '' }}" href="{{ route('admin.articles.index') }}">
                        <span class="nav-main-link-name">Articles</span>
                    </a>
                </li>
                @endif
               
            </ul>
        </li>
        @endif
        
        @if($admin && $admin->hasPermission('memberships.view'))
        <li class="nav-main-item">
            <a class="nav-main-link nav-main-link-submenu {{ request()->routeIs('admin.membership-plans.*') || request()->routeIs('admin.memberships.*') ? 'active' : '' }}" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                <i class="nav-main-link-icon si si-badge"></i>
                <span class="nav-main-link-name">Memberships</span>
            </a>
            <ul class="nav-main-submenu">
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.membership-plans.index') ? 'active' : '' }}" href="{{ route('admin.membership-plans.index') }}">
                        <span class="nav-main-link-name">Membership Plans</span>
                    </a>
                </li>
                @if($admin->hasPermission('memberships.approve'))
                <li class="nav-main-item">
                    <a class="nav-main-link {{ request()->routeIs('admin.memberships.pending') ? 'active' : '' }}" href="{{ route('admin.memberships.pending') }}">
                        <span class="nav-main-link-name">Membership Approvals</span>
                    </a>
                </li>
                @endif
            </ul>
        </li>
        @endif

        @if($admin && $admin->canViewTransactions())
        <li class="nav-main-item">
            <a class="nav-main-link {{ request()->routeIs('admin.transactions.*') ? 'active' : '' }}" href="{{ route('admin.transactions.index') }}">
                <i class="nav-main-link-icon si si-wallet"></i>
                <span class="nav-main-link-name">Transactions</span>
            </a>
        </li>
        @endif

        @if($admin && $admin->hasPermission('forums.view'))
        <li class="nav-main-item">
            <a class="nav-main-link {{ request()->routeIs('admin.forums.*') ? 'active' : '' }}" href="{{ route('admin.forums.index') }}">
                <i class="nav-main-link-icon si si-bubbles"></i>
                <span class="nav-main-link-name">Forums</span>
            </a>
        </li>
        @endif
      
        <li class="nav-main-heading">Account</li>
        <li class="nav-main-item">
            <a class="nav-main-link {{ request()->routeIs('admin.account.password') ? 'active' : '' }}" href="{{ route('admin.account.password') }}">
                <i class="nav-main-link-icon si si-lock"></i>
                <span class="nav-main-link-name">Change Password</span>
            </a>
        </li>
        <li class="nav-main-item">
            <form method="POST" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit" class="nav-main-link border-0 bg-transparent w-100 text-start">
                    <i class="nav-main-link-icon si si-logout"></i>
                    <span class="nav-main-link-name">Log Out</span>
                </button>
            </form>
        </li>
    </ul>
    </div>
    <!-- END Side Navigation -->
</div>
<!-- END Sidebar Scrolling -->
</nav>
<!-- END Sidebar -->
